package tower;
import shapes.*;
import java.util.*;

import javax.swing.JOptionPane;
/**
 * Clase que nos permite crear una tasa cuadrada con una base y dos paredes (todas de 1cm)
 * 
 * @author Fierro-Pachon
 * @version 05
 */
public class Taza extends Parte
{
    protected Rectangle base;
    protected Rectangle paredDer;
    protected Rectangle paredIzq;
    protected int insdIzq;
    protected int insdBot;
    protected int insdDer;
    protected boolean isCoveringIts = false;
    
    /**
     * Constructor of object of type cup
     */
    public Taza(int size, int[] top, int medio, ArrayList<Parte> partes, ArrayList<Integer> listaTipos,int contadorCambios,int totalObjetos,int tWidth,int topeTorre, boolean isVisible, String color)
    {
        super(size,color);
        this.isLided = false;
        this.lastY = 0;
        
        if (size > tWidth || size <= 0){
            this.ok = false;
        }
        else if (top[0] == 1 && top[1] - this.size >= topeTorre){
            //int height, int width, int xPosition, int yPosition, String color, boolean isVisible
            
            this.base = new Rectangle(10, this.size, medio-mid2, top[1]-10, myColor, isVisible);
            this.paredIzq = new Rectangle(this.size, 10, medio - mid2, top[1]-this.size, myColor, isVisible);
            this.paredDer = new Rectangle(this.size, 10, medio + mid2 - 10, top[1]-this.size, myColor, isVisible);
            this.contenida = false;
            this.ok = true;
            this.lastY = top[1]-10;
            
            this.insdDer = medio + mid2 - 10;
            this.insdIzq = medio - mid2 + 10;
            this.insdBot = top[1] - 10;
            this.topY = top[1] - this.size;
            if (totalObjetos != 0){
                partes.get(totalObjetos-1).setTopped(this);
            }
        }
        else if (top[0] == 0){
            //It means that the item on the top is a cup and we need to verify if it can be contained in
            
            if (partes.get(totalObjetos-contadorCambios).getSize() < this.size && top[1] - this.size > topeTorre || (this.size < partes.get(totalObjetos-contadorCambios).getSize() && this.size >= partes.get(totalObjetos-contadorCambios).getSize()-10)){
                this.base = new Rectangle(10, this.size, medio-mid2, top[1]-10, myColor, isVisible);
                this.paredIzq = new Rectangle(this.size, 10, medio - mid2, top[1]-this.size, myColor, isVisible);
                this.paredDer = new Rectangle(this.size, 10, medio + mid2 - 10, top[1]-this.size, myColor, isVisible);
                this.contenida = false;
                this.ok = true;
                this.lastY = top[1]-10;
                
                this.insdDer = medio + mid2 - 10;
                this.insdIzq = medio - mid2 + 10;
                this.insdBot = top[1] - 10;
                this.topY = top[1] - this.size;
                partes.get(totalObjetos-contadorCambios).setTopped(this);
                for (int y = totalObjetos-contadorCambios; y < totalObjetos;y++){
                    if (!partes.get(y).isTopped() && this.topY <= partes.get(y).getTopY()){
                        partes.get(y).setTopped(this);
                    }
                }
            }
            //It means that it can be contained, now we need to check what is inside
            else{
                boolean estado = true;
                int i = totalObjetos-contadorCambios;
                
                while (estado && i < totalObjetos){

                    if (!(partes.get(i).isDeep()) && !(partes.get(i).isTopped())){
                        
                        //It means that it does exist a lid inside and when we add a cup, the next element will be higher
                        if (partes.get(i).getTopY() -this.size >= topeTorre){
                            this.base = new Rectangle(10, this.size, medio-mid2, partes.get(i).getTopY()-10, myColor, isVisible);
                            this.paredIzq = new Rectangle(this.size, 10, medio - mid2, partes.get(i).getTopY()-this.size, myColor, isVisible);
                            this.paredDer = new Rectangle(this.size, 10, medio + mid2 - 10, partes.get(i).getTopY()-this.size, myColor, isVisible);
                            this.contenida = false;
                            this.ok = true;
                            this.lastY = partes.get(i).getTopY()-10;
                            
                            this.insdDer = medio + mid2 - 10;
                            this.insdIzq = medio - mid2 + 10;
                            this.insdBot = partes.get(i).getTopY()-10;
                            this.topY = partes.get(i).getTopY() - this.size;
                            partes.get(i).setTopped(this);
                            if (top[1] > partes.get(i).getTopY() -this.size){
                                this.contenida = false;
                            }
                            else{
                                this.contenida = true;
                            }
                            
                            for (int y = totalObjetos-contadorCambios; y < totalObjetos;y++){
                                if (!partes.get(y).isTopped() && this.topY <= partes.get(y).getTopY()){
                                    partes.get(y).setTopped(this);
                                }
                            }
                            estado = false;
                        }
                        
                    }
                    else if (partes.get(i).isDeep() && !(partes.get(i).isTopped()) ){

                        // The new cup is bigger than the one being analyzed
                        if (this.size > partes.get(i).getSize() && (partes.get(i).getTopY() - this.size) > topeTorre || (this.size < partes.get(i).getSize() && this.size >= partes.get(i).getSize()-10)){
                            this.base = new Rectangle(10, this.size, medio-mid2, partes.get(i).getTopY()-10, myColor, isVisible);
                            this.paredIzq = new Rectangle(this.size, 10, medio - mid2, partes.get(i).getTopY()-this.size, myColor, isVisible);
                            this.paredDer = new Rectangle(this.size, 10, medio + mid2 - 10, partes.get(i).getTopY()-this.size, myColor, isVisible);
                            this.ok = true;
                            this.lastY = partes.get(i).getTopY()-10;
                            
                            estado = false;
                            
                            this.insdDer = medio + mid2 - 10;
                            this.insdIzq = medio - mid2 + 10;
                            this.insdBot = partes.get(i).getTopY() - 10;
                            this.topY = partes.get(i).getTopY() - this.size;
                            partes.get(i).setTopped(this);
                            if (top[1] > partes.get(i).getTopY() -this.size){
                                this.contenida = false;
                            }
                            else{
                                this.contenida = true;
                            }
                            
                            for (int y = totalObjetos-contadorCambios; y < totalObjetos;y++){
                                if (!partes.get(y).isTopped() && this.topY <= partes.get(y).getTopY()){
                                    partes.get(y).setTopped(this);
                                }
                            }
                        }
                        // The cup being evaluated is the last one, so we need to check if we can put it inside 
                        else if ( this.size <= partes.get(i).getSize()-10 && (((Taza) partes.get(i)).getInsdBot() - this.size) > topeTorre && !(i+1<totalObjetos)){
                            this.base = new Rectangle(10, this.size, medio-mid2, ((Taza) partes.get(i)).getInsdBot()-10, myColor, isVisible);
                            this.paredIzq = new Rectangle(this.size, 10, medio - mid2, ((Taza) partes.get(i)).getInsdBot()-this.size, myColor, isVisible);
                            this.paredDer = new Rectangle(this.size, 10, medio + mid2 - 10, ((Taza) partes.get(i)).getInsdBot()-this.size, myColor, isVisible);
                            this.ok = true;
                            this.lastY = ((Taza) partes.get(i)).getInsdBot()-10;
                            
                            estado = false;
                            
                            this.insdDer = medio + mid2 - 10;
                            this.insdIzq = medio - mid2 + 10;
                            this.insdBot = ((Taza) partes.get(i)).getInsdBot()-10;
                            this.topY = ((Taza) partes.get(i)).getInsdBot() - this.size;
                            if (top[1] > ((Taza) partes.get(i)).getInsdBot() -this.size){
                                this.contenida = false;
                                partes.get(i).setTopped(this);
                            }
                            else{
                                this.contenida = true;
                            }
                            
                            for (int y = totalObjetos-contadorCambios; y < totalObjetos;y++){
                                if (!partes.get(y).isTopped() && this.topY <= partes.get(y).getTopY()){
                                    partes.get(y).setTopped(this);
                                }
                            }
                        }
                        else if (((Taza) partes.get(i)).getInsdBot() - this.size < topeTorre){
                            this.ok = false;
                            estado = false;
                        }

                    }
                    i ++;
                }
                
                if (estado){
                    this.ok = false;
                }
            }
        }
        else{
            this.ok = false;
        }
    }
    
    /**
     * Method that draw the cup
     */
    public void dibujar(){
        this.base.makeVisible();
        this.paredDer.makeVisible();
        this.paredIzq.makeVisible();
    }
    
    /**
     * Method that erreases the cup
     */
    public void borrar(){
        if (this.ok){
            this.base.makeInvisible();
            this.paredDer.makeInvisible();
            this.paredIzq.makeInvisible();
        }
    }
    
    /** 
     * Method to know the space inside a cup
     * @return a int value that indicates the space inside the cup
     */
    public int getInsdDer(){
        return this.insdDer;
    }
    
    /**
     * Method to know the delimitation of the base of the cup
     * @return a int value that indicates the delimitation of the base of the cup
     */
    public int getInsdBot(){
        return this.insdBot;
    }
    
    @Override
    /**
     * Method that indicates that this is a deep part
     */
    public boolean isDeep(){
        return true;
    }
    
    public void setLided(boolean is){
        this.isLided = is;
    }
    
    /**
     * Method that indicates if a Cup is common (normal)
     * @return a boolean value that will be true just if the cup is normal
     */
    public boolean isComon(){
        return false;
    }
    
    /**
     * Method that indicates if a Cup is ranked (hierarchical)
     * @return a boolean value that will be true just if the cup is hierarchical
     */
    public boolean isRanked(){
        return false;
    }
    
    /**
     * Method that indicates if a Cup is starter (opener)
     * @return a boolean value that will be true just if the cup is opener
     */
    public boolean isStarter(){
        return false;
    }
    
    /**
     * Method that indicates if a Cup is upper (top)
     * @return a boolean value that will be true just if the cup is top
     */
    public boolean isUpper(){
        return false;
    }
}