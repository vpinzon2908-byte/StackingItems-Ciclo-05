package tower;
import shapes.*;
import javax.swing.JOptionPane;
import java.util.*;
/**
* Class that let us manipulate a tower made of cups and lids
 * 
 * @author Fierro-Pachón 
 * @version 05
 */
public class Tower
{   
    private int width;//
    private int maxHeight;//
    private static ArrayList<Parte> partes;
    private HashMap<Integer, Parte[]> sizeParts;
    private int numTazas;//
    private int numTapas;//
        
    private static int[] top;
    private static int mitad;
    private static int contadorCambios;
    private static int contadorTotalObjetos;
    private static ArrayList<Integer> tipoEntrada;
    private static boolean lastOk;
    private int tope;
    private int masBajo;
    private boolean visible;
    private static ArrayList<String> colors;
    private int numColor = 0;
    
    private static Rectangle ejeY;
    private static Rectangle[] ejeYParts;
    private boolean recalculating = false;
    private boolean existTop = false;
    
    /**
     * Constructor of objects type tower
     * @param width represents the maximum width of the tower
     * @param maxHeight represents the maximum height of the tower
     */
    public Tower(int width, int maxHeight, float mitadEx, int parteMasBaja)
    {
        this.width = width;
        this.maxHeight = maxHeight;
        top = new int[2];
        mitad = (int) mitadEx;
        tope = parteMasBaja-maxHeight * 10;
        this.masBajo = parteMasBaja;
        
        // In the first position (position 0) we indicate if it is a cup (0) or a lid (1)
        // In the second position (position 1) we have the element that is upper
        this.top[0] = 1;
        this.top[1] = parteMasBaja;
        
        this.partes = new ArrayList<Parte>();
        this.sizeParts = new HashMap();
        
        contadorCambios = 0;
        tipoEntrada = new ArrayList<Integer>();
        contadorTotalObjetos = 0;
        this.visible = false;
        setColorList();
        lastOk = true;
        
        // grid construction
        this.ejeY = new Rectangle(maxHeight*10, 3, 35, parteMasBaja-maxHeight*10, "black", false);
        Rectangle[] eslabones = new Rectangle[maxHeight+1];
        int pos = parteMasBaja;
        for(int i = 0 ; i <= maxHeight ; i++){
            eslabones[i] = new Rectangle(3, width, 30, pos, "gray", false);
            pos -= 10;
        }
        this.ejeYParts = eslabones;
        }
        
    /**
     * Constructor that creates a tower of a given amount of cups
     * @param cups indicates the amount of cups in the tower
     */
    public Tower(int cups, float mitadEx, int parteMasBaja,int width, int maxHeight){
        this(width, maxHeight, mitadEx, parteMasBaja);
        // we create a tower
        // we start to draw the cups with size = 2*i-1, where i is the position
        for (int i = 1; i < cups+1 ;i++){
            int size = 2 * i - 1;
            this.pushCup(size, "normal");
        }
        
    }
    
    public final void pushCup(int i)
    {   
        if (i > 0 && sizeParts.get(i) == null){
            Parte[] a = new Parte[2];
            a[0] = null;
            a[1] = null;
            sizeParts.put(i,a);
        }
        if (i > 0 && sizeParts.get(i)[0] == null && !existTop){
            Taza nueva = new TazaNormal(i,top,mitad,partes,tipoEntrada,contadorCambios,contadorTotalObjetos,width,tope,visible,getAColor(i));
            
            if (nueva.ok()){
                contadorTotalObjetos += 1;
                partes.add(nueva);
                
                tipoEntrada.add(0);
                //counter of the changes during the creation
                this.numTazas += 1;
                lastOk = true;
                Arrays.toString(top);
                if (nueva.getContenida()){
                    contadorCambios += 1;
                }
                else{
                    top[0] = 0;
                    /*
                    JOptionPane.showMessageDialog(null, nueva.getTopY(),
                                                                "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
                    */
                    top[1] = top[1] - (top[1] - nueva.getTopY());
                    contadorCambios = 1;
                }
                /*
                JOptionPane.showMessageDialog(null, "Dentro abajo"+nueva.getInsdBot()+"Dentro derecha"+nueva.getInsdDer(),
                                                                "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
                */
                Parte[] b = sizeParts.get(i);
                b[0] = nueva;
                sizeParts.put(i,b);
                
            }
            else{
                nueva.borrar();
                lastOk = false;
            }
        }
        else{
            lastOk = false;
            if(this.visible && this.existTop){
                JOptionPane.showMessageDialog(null, "En la torre existe una tapa top, por lo que ya no puede añadir más tapas");
            }
        }
        this.numColor ++;
    }
    
    /**
     * Method that adds a cup in the ith position
     * 
     * @param  i  position where we are going to add the new cup
     */
    public final void pushCup(int i, String type)
    {   
        if (i > 0 && sizeParts.get(i) == null){
            Parte[] a = new Parte[2];
            a[0] = null;
            a[1] = null;
            sizeParts.put(i,a);
        }
        if (i > 0 && sizeParts.get(i)[0] == null && !existTop){
        
            Taza nueva;
            
            if (type.equals("opener")){

                ArrayList<Parte> lidsToRemove = new ArrayList<>();
                
                for (Parte part : this.partes) {
                    if (!part.isDeep() && part.getSize() < i) {
                        lidsToRemove.add(part);
                    }
                }
                
                for (Parte part : lidsToRemove) {
                    this.removeLid(part.getSize()); // o remove directamente por objeto
                }
                nueva = new TazaOpener(i,top,mitad,partes,tipoEntrada,contadorCambios,contadorTotalObjetos,width,tope,visible,getAColor(i));
            }
            else if (type.equals("hierarchical")){
                nueva = new TazaHierarchical(i,top,mitad,partes,tipoEntrada,contadorCambios,contadorTotalObjetos,width,tope,visible,getAColor(i));
            }
            else if (type.equals("top")){
                nueva = new TazaTop(i,top,mitad,partes,tipoEntrada,contadorCambios,contadorTotalObjetos,width,tope,visible,getAColor(i));
                this.existTop = true;
            }
            else{
                nueva = new TazaNormal(i,top,mitad,partes,tipoEntrada,contadorCambios,contadorTotalObjetos,width,tope,visible,getAColor(i));
            }
            
            if (nueva.ok()){
                contadorTotalObjetos += 1;
                partes.add(nueva);
                
                tipoEntrada.add(0);
                //counter of the changes during the creation
                this.numTazas += 1;
                lastOk = true;
                Arrays.toString(top);
                if (nueva.getContenida()){
                    contadorCambios += 1;
                }
                else{
                    top[0] = 0;
                    /*
                    JOptionPane.showMessageDialog(null, nueva.getTopY(),
                                                                "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
                    */
                    top[1] = top[1] - (top[1] - nueva.getTopY());
                    contadorCambios = 1;
                }
                /*
                JOptionPane.showMessageDialog(null, "Dentro abajo"+nueva.getInsdBot()+"Dentro derecha"+nueva.getInsdDer(),
                                                                "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
                */
                Parte[] b = sizeParts.get(i);
                b[0] = nueva;
                sizeParts.put(i,b);
                
            }
            else{
                nueva.borrar();
                lastOk = false;
            }
        }
        else{
            lastOk = false;
            if(this.visible && this.existTop){
                JOptionPane.showMessageDialog(null, "En la torre existe una taza top, por lo que ya no puede añadir más tazas");
            }
        }
        this.numColor ++;
    }
    
    /**
     * Method that deletes the last cup added (LIFO)
     * This is, it deletes the cup that is in the upper part of the tower
     */
    public final void popCup()
    {      
        if (contadorTotalObjetos >= 1){
            if (partes.get(contadorTotalObjetos-1).isDeep()){
                Parte tazaEliminar = partes.get(contadorTotalObjetos-1);
                
                Parte[] b = sizeParts.get(tazaEliminar.getSize()/10);
                b[0] = null;
                sizeParts.put(tazaEliminar.getSize()/10,b);
                partes.remove(contadorTotalObjetos-1);
                
                if (this.contadorCambios >= 1){
                    this.contadorCambios -= 1;
                }
                if (((Taza) tazaEliminar).isUpper()){
                    this.existTop = false;
                }
                tipoEntrada.remove(contadorTotalObjetos-1);
                contadorTotalObjetos -= 1;
                deleteTopped(tazaEliminar);
                tazaEliminar.borrar();
                setTop();
                lastOk = true;
            }
            else{
                lastOk = false;
            }
        }
        else{
            lastOk = false;
        }
    }
    
    /**
     * Method that removes the cup in the ith position
     * 
     * @param  i  position in wich is located the cup that we will delete
     */
    public final void removeCup(int t)
    {
        boolean can = true;
        if (sizeParts.get(t) == null || sizeParts.get(t)[0] == null){
            can = false;
        }
        
        if (can){
            int toDelete = partes.indexOf(sizeParts.get(t)[0]);
            Parte[] a = sizeParts.get(t);
            a[0] = null;
            sizeParts.put(t,a);
            Parte el = partes.get(toDelete);
            if (el.isLided()){
                removeLid(t,"Special");
            }
            deleteTopped(el);
            if (((Taza) el).isUpper()){
                this.existTop = false;
            }
            el.borrar();
            partes.remove(toDelete);
            this.contadorTotalObjetos -= 1;
            recalculate();
            this.lastOk = true;
        }
        else{
            this.lastOk = false;
        }
    }
    
    public final void pushLid(int i)
    {   
        if (i > 0 && sizeParts.get(i) == null){
            Parte[] a = new Parte[2];
            a[0] = null;
            a[1] = null;
            sizeParts.put(i,a);
        }
            
        if (i > 0 && sizeParts.get(i)[1] == null){

            Tapa nueva = new TapaNormal(i,top,mitad,partes,tipoEntrada,contadorCambios,contadorTotalObjetos,width,tope,visible,getAColor(i));
            
            if (nueva != null && nueva.ok()){
                contadorTotalObjetos += 1;
                partes.add(nueva);
                tipoEntrada.add(1);
                //counter of changes during the creation of the lid
                this.numTapas += 1; 
                lastOk = true;
                if (nueva.getContenida()){
                    contadorCambios += 1;
                }
                else{
                    top[0] = 1;
                    top[1] = top[1] - (top[1] - nueva.getTopY());
                    contadorCambios = 0;
                }
                /*
                JOptionPane.showMessageDialog(null, nueva.getY(),
                                                                "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
                */
                
                Parte[] b = sizeParts.get(i);
                b[1] = nueva;
                sizeParts.put(i,b);
            }
            else{
                if (nueva != null) {
                    nueva.borrar();
                }
                lastOk = false;
            }
        }
        else {
            lastOk = false;
        }
        
        this.numColor ++;
    }
    
    /**
     * Method that adds the lid in the ith position
     * 
     * @param  i  size of the new lid
     */
    public final void pushLid(int i, String type)
    {   
        if (i > 0 && sizeParts.get(i) == null){
            Parte[] a = new Parte[2];
            a[0] = null;
            a[1] = null;
            sizeParts.put(i,a);
        }
        boolean canBeFearful = false;
            
        if (i > 0 && sizeParts.get(i)[1] == null){

            Tapa nueva;
            
            if (type.equals("fearful")){
                for(Parte part : this.partes){
                    if (part.getSize()/10 == i && part.isDeep()){
                        
                        canBeFearful = true;
                    }
                }
                if(canBeFearful){
                    nueva = new TapaFearful(i,top,mitad,partes,tipoEntrada,contadorCambios,contadorTotalObjetos,width,tope,visible,getAColor(i));
                }
                else{
                    nueva = null;
                }
            }
            else if (type.equals("crazy")){
                nueva = new TapaCrazy(i,top,mitad,partes,tipoEntrada,contadorCambios,contadorTotalObjetos,width,tope,visible,getAColor(i));
            }
            else{
                nueva = new TapaNormal(i,top,mitad,partes,tipoEntrada,contadorCambios,contadorTotalObjetos,width,tope,visible,getAColor(i));
            }
            
            if (nueva != null && nueva.ok()){
                contadorTotalObjetos += 1;
                partes.add(nueva);
                tipoEntrada.add(1);
                //counter of changes during the creation of the lid
                this.numTapas += 1;
                lastOk = true;
                if (nueva.getContenida()){
                    contadorCambios += 1;
                }
                else{
                    top[0] = 1;
                    top[1] = top[1] - (top[1] - nueva.getTopY());
                    contadorCambios = 0;
                }
                /*
                JOptionPane.showMessageDialog(null, nueva.getY(),
                                                                "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
                */
                
                Parte[] b = sizeParts.get(i);
                b[1] = nueva;
                sizeParts.put(i,b);
            }
            else{
                if (nueva != null) {
                    nueva.borrar();
                }
                lastOk = false;
            
                if (this.visible && type.equals("fearful") && !canBeFearful){
                    JOptionPane.showMessageDialog(null, 
                        "No existen tazas de ese tamaño por lo que no se puede añadir una tapa fearful");
                }
            }
        }
        else {
            lastOk = false;
        }
        
        this.numColor ++;
    }
    
    /**
     * Método that deletes the last lid added.
     */
    public final void popLid()
    {
        if (contadorTotalObjetos >= 1){
            if (!partes.get(contadorTotalObjetos-1).isDeep()){
                Parte tapaEliminar = partes.get(contadorTotalObjetos-1);
                Parte[] b = sizeParts.get(tapaEliminar.getSize()/10);
                b[1] = null;
                sizeParts.put(tapaEliminar.getSize()/10,b);
                partes.remove(contadorTotalObjetos-1);
                
                if (this.contadorCambios >= 1){
                    this.contadorCambios -= 1;
                }
                tipoEntrada.remove(contadorTotalObjetos-1);
                contadorTotalObjetos -= 1;
                
                if (sizeParts.get(tapaEliminar.getSize()/10)[0] != null && ((Taza) sizeParts.get(tapaEliminar.getSize()/10)[0]).isLided()){
                    ((Taza) sizeParts.get(tapaEliminar.getSize()/10)[0]).setLided(false);
                }
                deleteTopped(tapaEliminar);
                setTop();
                tapaEliminar.borrar();
                lastOk = true;
            }
            else{
                lastOk = false;
            }
        }
        else{
            lastOk = false;
        }

    }
    
    /**
     * Method that removes the lid in the ith position
     * 
     * @param  i  position in wich is located the cup that we will delete
     */
    public final void removeLid(int t)
    {
        boolean can = true;
        if (sizeParts.get(t) == null || sizeParts.get(t)[1] == null){
            can = false;
        }
        
        if (can){
            int toDelete = partes.indexOf(sizeParts.get(t)[1]);
            Parte[] a = sizeParts.get(t);
            a[1] = null;
            sizeParts.put(t,a);
            Parte el = partes.get(toDelete);
            el.borrar();
            deleteTopped(el);
            partes.remove(toDelete);
            this.contadorTotalObjetos -=1;
            recalculate();
            this.lastOk = true;
        }
        else{
            this.lastOk = false;
        }

    }
    
    public final void removeLid(int t, String special)
    {
        int toDelete = partes.indexOf(sizeParts.get(t)[1]);
        Parte[] a = sizeParts.get(t);
        a[1] = null;
        sizeParts.put(t,a);
        Parte el = partes.get(toDelete);
        el.borrar();
        deleteTopped(el);
        partes.remove(toDelete);
        this.contadorTotalObjetos -=1;
    }
    
    private void deleteTopped(Parte p){
        for (Parte part : partes){
            if (part.getTopped() == p){
                part.setTopped(null);
            }
        }
    }
    
    private void setTop(){
        if (partes.size() < 1 ){
            this.top[0] = 1;
            this.top[1] = this.masBajo;
        }
        else{
            Parte maxim = partes.get(0);
            for (Parte p: partes){
                if (p.getTopY() <= maxim.getTopY()){
                    maxim = p;
                }
            }
            if (maxim.isDeep()){
                top[0] = 0;
            }
            else{
                top[0] = 1;
            }
            top[1] = maxim.getTopY();
        }
    }
    
    /**
     * Method that organices the towers from biggest to smallest
     * So the smallest item will always be at the top of the tower
     * If we have a cup and a lid of the same size, we must put them together
     */
    public void orderTower(){
        this.existTop = false;
        
        HashMap<Integer,ArrayList<Parte>> temporal = new HashMap();
        boolean cerrando = false;
        int i = 0;
        int sizeClosing = -1;
        ArrayList<Parte> dentro = new ArrayList<>();
        
        while (i < partes.size()){
            
            if (!cerrando && partes.get(i).isDeep() && ((Taza) partes.get(i)).isLided()){
                cerrando = true;
                sizeClosing = partes.get(i).getSize();
                dentro = new ArrayList<>();
                
            }
            else if (cerrando && !partes.get(i).isDeep() && partes.get(i).getSize() == sizeClosing){
                cerrando = false;
                temporal.put(sizeClosing,dentro);
                
            }
            else if (cerrando){
                dentro.add(partes.get(i));
                
                if (partes.get(i).isDeep()){
                    Parte[] a = sizeParts.get(partes.get(i).getSize()/10);
                    a[0] = null;
                    sizeParts.put(partes.get(i).getSize()/10,a);
                    
                }
                else if (!partes.get(i).isDeep()){
                    Parte[] a = sizeParts.get(partes.get(i).getSize()/10);
                    a[1] = null;
                    sizeParts.put(partes.get(i).getSize()/10,a);
                    
                }
                partes.remove(i);
                i--;
                
            }
            i ++;
        }

        Set<Integer> aux1= sizeParts.keySet();
        List<Integer> aux = new ArrayList<>(aux1);
        Collections.sort(aux,Collections.reverseOrder());
        partes.clear();
        Parte[] par ;

        for (Integer num : aux){
            par = sizeParts.get(num);
            if (par[0] != null){
                partes.add(par[0]);
            }
            if (par[1] != null){
                partes.add(par[1]);
            }
        }

        i = 0;
        while (i < partes.size()){
            if (temporal.get(partes.get(i).getSize()) != null && partes.get(i).isDeep()){
                partes.addAll(i+1,temporal.get(partes.get(i).getSize()));
            }
            i++;
        }
        
        recalculate();
        this.lastOk = true;
    }
    
    /**
     * Method that organices from smaller to the biggest
     * So the smallest item will always be at the top of the tower
     */
    public void reverseTower()
    {
        this.existTop = false;
        
        HashMap<Integer,ArrayList<Parte>> temporal = new HashMap();
        boolean cerrando = false;
        int i = 0;
        int sizeClosing = -1;
        ArrayList<Parte> dentro = new ArrayList<>();
        
        while (i < partes.size()){
            
            if (!cerrando && partes.get(i).isDeep() && ((Taza) partes.get(i)).isLided()){
                cerrando = true;
                sizeClosing = partes.get(i).getSize();
                dentro = new ArrayList<>();
                
            }
            else if (cerrando && !partes.get(i).isDeep() && partes.get(i).getSize() == sizeClosing){
                cerrando = false;
                temporal.put(sizeClosing,dentro);
                
            }
            else if (cerrando){
                dentro.add(partes.get(i));
                
                if (partes.get(i).isDeep()){
                    Parte[] a = sizeParts.get(partes.get(i).getSize()/10);
                    a[0] = null;
                    sizeParts.put(partes.get(i).getSize()/10,a);
                    
                }
                else if (!partes.get(i).isDeep()){
                    Parte[] a = sizeParts.get(partes.get(i).getSize()/10);
                    a[1] = null;
                    sizeParts.put(partes.get(i).getSize()/10,a);
                    
                }
                partes.remove(i);
                i--;
                
            }
            i ++;
        }
        
        Set<Integer> aux1= sizeParts.keySet();
        List<Integer> aux = new ArrayList<>(aux1);
        partes.clear();
        Parte[] par ;
        for (Integer num : aux){
            par = sizeParts.get(num);
            if (par[0] != null){
                partes.add(par[0]);
            }
            if (par[1] != null){
                partes.add(par[1]);
            }
        }
        
        i = 0;
        while (i < partes.size()){
            if (temporal.get(partes.get(i).getSize()) != null && partes.get(i).isDeep()){
                partes.addAll(i+1,temporal.get(partes.get(i).getSize()));
            }
            i++;
        }
        
        recalculate();
        this.lastOk = true;
    }
    
    /**
     * Method that lets us swap two objects from the tower
     * @param first A String that comes in the form {type,size} this is the object to swap
     * @param last A String that comes in the form {type,size} this is the object whom we are swapping places with
     */
    public void swap(String [] first, String [] last){
        boolean can = true;
        
        if (first[0].equals("cup")){
            if (sizeParts.get(Integer.parseInt(first[1])) == null || sizeParts.get(Integer.parseInt(first[1]))[0] == null){
                can = can && false;
            }
        }
        else if (first[0].equals("lid")){
            if (sizeParts.get(Integer.parseInt(first[1])) == null || sizeParts.get(Integer.parseInt(first[1]))[1] == null){
                can = can && false;
            }
        }
        else{
            can = can && false;
        }
        
        if (last[0].equals("cup")){
            if (sizeParts.get(Integer.parseInt(last[1])) == null || sizeParts.get(Integer.parseInt(last[1]))[0] == null){
                can = can && false;
            }
        }
        else if (last[0].equals("lid")){
            if (sizeParts.get(Integer.parseInt(last[1])) == null || sizeParts.get(Integer.parseInt(last[1]))[1] == null){
                can = can && false;
            }
        }
        else{
            can = can && false;
        }
        
        if (can && contadorTotalObjetos >= 2){
            int firstSwap = auxGetPos(first);
            int lastSwap = auxGetPos(last);
            //change the references of the position to the object
            changePos(firstSwap,lastSwap);
            
            //we recalculate all the tower
            recalculate();
            
            lastOk = true;
        }
        else {
            lastOk = false;
        }
    }
    
    public String[][] swapToReduce(){
        ArrayList<Parte> aux = new ArrayList<>(partes);
        boolean vis = this.visible;
        this.makeInvisible("swapping");
        boolean changed = false;
        int actual = height();
        String[] uno = new String[]{"0","0"};
        String[] dos = new String[]{"0","0"};
        out:
        for (Parte p : aux){
            for (Parte t: aux){
                partes.clear();
                partes.addAll(aux);
                recalculate();
                uno = new String[2];
                dos = new String[2];
                if (p.isDeep()){
                    uno[0] = "cup";
                }
                else{
                    uno[0] = "lid";
                }
                uno[1] = String.valueOf(p.getSize()/10);
                if (t.isDeep()){
                    dos[0] = "cup";
                }
                else{
                    dos[0] = "lid";
                }
                dos[1] = String.valueOf(t.getSize()/10);
                swap(uno,dos);
                int cambio = height();
                if (cambio < actual){
                    changed = true;
                    break out;
                }
            }
        }
        String[][] forReturn = new String[][]{{"0","0"},{"0","0"}};
        if (changed){
            forReturn[0] = uno;
            forReturn[1] = dos;
        }
        partes.clear();
        partes.addAll(aux);
        recalculate();
        if(vis){
            makeVisible("stopped swapping");
        }
        else{
            makeInvisible("stopped swapping");
        }
        this.lastOk = true;
        return forReturn;
    }
    
    private void recalculate (){
        //we erase all the objects from the position we are swapping positions
        ArrayList<Parte> aux = new ArrayList<Parte>();
        
        for (int i = contadorTotalObjetos-1; i >= 0;i--){
            aux.add(partes.get(i));
            partes.get(i).borrar();
        }
        //now we prepare everything to push all the objects in order
        
        top[0] = 1;
        top[1] = this.masBajo;
        this.partes = new ArrayList<>();
        this.sizeParts = new HashMap();
        
        contadorCambios = 0;
        tipoEntrada = new ArrayList<Integer>();
        contadorTotalObjetos = 0;
        
        //now that we have the new 'top' of the tower, we push all the things in order
        for (int i = aux.size()-1; i > -1;i--){
            if (aux.get(i).isDeep()){
                String type = "normal";
                Taza cup = (Taza) aux.get(i);
                if (cup.isRanked()){
                    type = "hierarchical";
                }
                else if (cup.isStarter()){
                    type = "opener";
                }
                else if (cup.isUpper()){
                    type = "top";
                }
                
                pushCup(aux.get(i).getSize()/10, type);
            }
            else{
                String type = "normal";
                Tapa cup = (Tapa) aux.get(i);
                if (cup.isAfraid()){
                    type = "fearful";
                }
                else if (cup.isSilly()){
                    type = "crazy";
                }
                
                pushLid(aux.get(i).getSize()/10, type);
            }
            
        }
    }
    
    /*
     * This method helps us change the positions in the hashmaps of the objects to swap
     */
    private void changePos(int firstPos, int lastPos){
        Parte first = partes.get(firstPos);
        Parte last = partes.get(lastPos);
        
        partes.set(lastPos,first);
        partes.set(firstPos,last);
    }
    
    
    private int auxGetPos(String [] aux){
        int forReturn;
        Parte part;
        if (aux[0].equals("cup")){
            part = sizeParts.get(Integer.parseInt(aux[1]))[0];
        }
        else{
            part = sizeParts.get(Integer.parseInt(aux[1]))[1];
        }
        
        forReturn = partes.indexOf(part);
            
        return forReturn;
    }
    
     /**
     * Mthod that shows the height of the tower
     * @return an int that is the height of the tower
     */
    public int height()
    {
        this.lastOk = true;
        return (this.masBajo - getTop()[1])/10;
        
    }
    
     /**
     * Method that returns the amount of cups that are covered with its respective lids
     * ordered from smallest to bigest
     * @return an array of ints
     */
    public int[] lidedCups()
    {
        int cont = 0;
        ArrayList<Integer> ls = new ArrayList<>();
        
        for (Parte part : partes){
            if (part.isLided()){
                ls.add(part.getSize()/10);
                cont ++;
            }
        }
        int [] forReturn = new int[cont];
        
        for (int i = 0; i < cont; i++){
            forReturn[i] = ls.get(i);
        }
        this.lastOk = true;
        return forReturn;
    }
    
     /**
     * Method that presents the elements ordered from base to top in lowercase
     * Ejemplo: {{"cup", "4"}, {"lid", "4"}}
     * @return a 2D String array
     */
    public String[][] stackingItems()
    {
        String [][] forReturn = new String[contadorTotalObjetos][2];

        for (int i = 0; i < contadorTotalObjetos;i++){
            if (partes.get(i).isDeep()){
                forReturn[i][0] = "cup";
                
            }
            else{
                forReturn[i][0] = "lid";
                
            }
            forReturn[i][1] = String.valueOf(partes.get(i).getSize()/10);
        }
        lastOk = true;
        return forReturn;
    }
    
    public String[][] stackingCups()
    {   
        int cups = 0;
        for (Parte p : partes){
            if (p.isDeep()){
                cups ++;
            }
        }
        
        if (cups != 0){
            String [][] forReturn = new String[cups][2];
            int aux = 0;
            for (Parte p : partes){
                if (p.isDeep()){
                    forReturn[aux][0] = "cup";
                    forReturn[aux][1] = String.valueOf(p.getSize()/10);
                    aux ++;
                }
            }
            lastOk = true;
            return forReturn;
        }
        else{
            lastOk = false;
            return new String [0][0];
        }
    }
    
    public String[][] stackingLids()
    {
        int lids = 0;
        for (Parte p : partes){
            if (p.isDeep()){
                lids ++;
            }
        }
        
        if (lids != 0){
            String [][] forReturn = new String[lids][2];
            int aux = 0;
            for (Parte p : partes){
                if (!p.isDeep()){
                    forReturn[aux][0] = "lid";
                    forReturn[aux][1] = String.valueOf(p.getSize()/10);
                    aux++;
                }
            }
            lastOk = true;
            return forReturn;
        }
        else{
            lastOk = false;
            return new String [0][0];
        }
    }
    
    /** Method that makes visible the tower
     */
    public void makeVisible(){
        ejeY.makeVisible();
        for(Rectangle square : this.ejeYParts){
            square.makeVisible();
        }    
        
        for (Parte part : partes){
            part.dibujar();
        }
        this.visible = true;
        this.lastOk = true;
    }
    
    public void makeVisible(String s){
        for (Parte part : partes){
            part.dibujar();
        }
        this.visible = true;
        this.lastOk = true;
    }
    
    /**
     * Method that makes invisible the tower
     */
    public void makeInvisible(){
        for (Parte part : partes){
            part.borrar();
        }
        ejeY.makeInvisible();
        for (Rectangle r : this.ejeYParts){
            r.makeInvisible();
        }
        this.visible = false;
        this.lastOk = true;
    }
    
    public void makeInvisible(String s){
        for (Parte part : partes){
            part.borrar();
        }
        
        this.visible = false;
        this.lastOk = true;
    }
    
    /**
     * Method that help us to lock out from the interaction with the object
     */
    public void exit(){
        this.makeInvisible();
        this.top[0] = 1;
        this.top[1] = masBajo;
        this.ejeY.makeInvisible();
        for(Rectangle square : this.ejeYParts){
            square.makeInvisible();
        }
        
        this.partes = new ArrayList<Parte>();
        this.sizeParts = new HashMap();
        
        contadorCambios = 0;
        tipoEntrada = new ArrayList<Integer>();
        contadorTotalObjetos = 0;
        colors.clear();
        setColorList();
        lastOk = true;
        
    }
    
    /** 
     * Method to obtain the object that is in the top
     * @return a array if integers
     */
    public static int[] getTop(){
        return top;
    }
    
    /**
     * Method to obtain the middle of the canvas
     */
    public static int getMitad(){
        return mitad;
    }
    
    /**
     * Method that help us to update the top of the tower
     */
    public static void setTop(int [] nuevoTop){
        top = nuevoTop;
    }
    
    
    /**
     * Method to obtain the status of the last action
     * @return a boolean that indicates if the last action is done
     */
    public boolean ok(){
        return lastOk;
    }
    
    public void setOk(boolean s){
        this.lastOk = s;
    }
    
    /**
     * Method that gets the total of objects
     * @return an int with the amunt of objects in the tower
     */
    public static int getTotalObjetos(){
        return contadorTotalObjetos;
    }
    
    /**
     * Method that gets the cups HashMap
     * @return a HasMap with the cups
     */
    public static ArrayList<Parte> getPartes(){
        return partes;
    }
    
    /**
     * Method that gets the list of types
     * @return an ArrayList of Integers
     */
    public static ArrayList<Integer> getListaTipos(){
        return tipoEntrada;
    }
    
    /**
     * Method that gets the number of changes
     * @return an int with the number of changes
     */
    public static int getContadorCambios(){
        return contadorCambios;
    }
    
    /**
     * Method that gets the top of the tower
     * @return the atribute that keeps the top of the tower
     */
    public int getTope(){
        return this.tope;
    }
    
    private static void setColorList(){
        colors = new ArrayList<>();
        colors.add("black");
        colors.add("red");
        colors.add("green");
        colors.add("blue");
        colors.add("cyan");
        colors.add("magenta");
        colors.add("yellow");
        colors.add("orange");
        colors.add("pink");
        colors.add("gray");
    }   
    
    private String getAColor(){
        String color;
        color = this.colors.get(this.numColor%10);
        return color;
    }
    
    private String getAColor(int i){
        String color;
        color = this.colors.get(i%10);
        return color;
    }
    
    public String[][] getTopped()
    {   
        int cont = 0;
        for (Parte p: partes){
            if (p.isTopped()) cont++;
        }
        String [][] forReturn = new String[cont][2];
        cont = 0;
        for (Parte p: partes){
            if (p.isTopped()){
                if (p.isDeep()){
                    forReturn[cont][0] = "cup";
                    
                }
                else{
                    forReturn[cont][0] = "lid";
                    
                }
                forReturn[cont][1] = String.valueOf(p.getSize()/10);
                cont ++;
            }
        }
        lastOk = true;
        return forReturn;
    }
    
    public void rerun(){
        this.makeInvisible();
        this.top[0] = 1;
        this.top[1] = masBajo;
        
        this.partes = new ArrayList<Parte>();
        this.sizeParts = new HashMap();
        
        contadorCambios = 0;
        tipoEntrada = new ArrayList<Integer>();
        contadorTotalObjetos = 0;
        colors.clear();
        setColorList();
        lastOk = true;
        
    }
    
    public static String[] getTopY(){
        String [] forReturn = new String[contadorTotalObjetos];
        for (int i = 0; i < contadorTotalObjetos;i++){
            forReturn[i] = String.valueOf(partes.get(i).getTopY());
        }
        
        return forReturn;
    }
    
    public boolean isVisible(){
        return this.visible;
    }

}