package tower;
import shapes.*;
import java.util.*;
import javax.swing.JOptionPane;
/**
 * Class that creates cups
 * 
 * @author Fierro-Pachon 
 * @version 05
 */
public class Tapa extends Parte
{
    protected Rectangle lid;
    protected Rectangle differentiator1;
    protected Rectangle differentiator2;
    protected boolean isLid;
    protected int medio;
    
    /**
     * Constructor of objects type lid
     */
    public Tapa(int size, int[] top, int medio, ArrayList<Parte> partes, ArrayList<Integer> listaTipos,int contadorCambios,int totalObjetos,int tWidth,int topeTorre,boolean isVisible, String color)
    {
        super(size,color);
        this.isLided = false;
        this.differentiator1 = null;
        this.differentiator2 = null;
        this.medio = medio;
        if (size > tWidth || size <= 0){
            this.ok = false;
        }
        else if (top[0] == 1 && top[1] - 10 >= topeTorre){
            //int height, int width, int xPosition, int yPosition, String color, boolean isVisible
            
            this.lid = new Rectangle(10, this.size, medio-mid2, top[1]-10, myColor, isVisible);
            
            this.topY = top[1] - 10;
            this.contenida = false;
            this.ok = true;
            if (totalObjetos != 0){
                partes.get(totalObjetos-1).setTopped(this);
            }
                
        }
        else if (top[0] == 0){
            //It means that the item on the top is a cup and we need to verify if it can be contained in
            
            if (this.size >= partes.get(totalObjetos-contadorCambios).getSize() || (this.size >= partes.get(totalObjetos-contadorCambios).getSize()-10 && this.size < partes.get(totalObjetos-contadorCambios).getSize())){
                this.lid = new Rectangle(10, this.size, medio-mid2, top[1]-10, myColor, isVisible);

                this.contenida = false;
                this.ok = true;
                this.topY = top[1] - 10;
                partes.get(totalObjetos-contadorCambios).setTopped(this);
                if (this.size == partes.get(totalObjetos-contadorCambios).getSize()){
                    ((Taza) partes.get(totalObjetos-contadorCambios)).setLided(true);
                    this.covered(isVisible);
                }
                for (int y = totalObjetos-contadorCambios; y < totalObjetos;y++){
                    if (!partes.get(y).isTopped() && this.topY <= partes.get(y).getTopY()){
                        partes.get(y).setTopped(this);
                    }
                }
            }
            //It means that it can be contained and we need to verify the elemnts in the inside
            else{
                boolean estado = true;
                int i = totalObjetos-contadorCambios;
                
                while (estado && i < totalObjetos){

                    if (!(partes.get(i).isDeep()) && !(partes.get(i).isTopped())){

                        //It means that it does exist a lid inside and when we add a cup, the nexxt element will be higher
                        if (partes.get(i).getTopY() - 10 >= topeTorre){
                            this.lid = new Rectangle(10, this.size, medio-mid2, partes.get(i).getTopY()-10, myColor, isVisible);

                            this.ok = true;
                            this.topY = partes.get(i).getTopY() - 10;
                            if (top[1] > (partes.get(i).getTopY() -10)){
                                this.contenida = false;
                            }
                            else{
                                this.contenida = true;
                            }
                            partes.get(i).setTopped(this);
                            estado = false;
                        }
                    }
                    else if (partes.get(i).isDeep() && !(partes.get(i).isTopped())){

                        if (this.size >= partes.get(i).getSize() || (this.size >= partes.get(i).getSize()-10 && this.size < partes.get(i).getSize())){
                            this.lid = new Rectangle(10, this.size, medio-mid2, partes.get(i).getTopY()-10, myColor, isVisible);


                            this.ok = true;
                            this.topY = partes.get(i).getTopY() - 10;
                            partes.get(i).setTopped(this);
                            if (top[1] > partes.get(i).getTopY()-10){
                                this.contenida = false;
                            }
                            else{
                                this.contenida = true;
                            }
                            
                            if (this.size == partes.get(i).getSize()){
                                ((Taza) partes.get(i)).setLided(true);
                                this.covered(isVisible);
                            }
                            for (int y = totalObjetos-contadorCambios; y < totalObjetos;y++){
                                if (!partes.get(y).isTopped() && this.topY <= partes.get(y).getTopY()){
                                    partes.get(y).setTopped(this);
                                }
                            }
                            estado = false;
                        }
                        
                        else if (this.size <= partes.get(i).getSize()-10 && !(i+1<totalObjetos)){
                            this.lid = new Rectangle(10, this.size, medio-mid2,((Taza) partes.get(i)).getInsdBot()-10, myColor, isVisible);


                            this.ok = true;
                            this.topY = ((Taza) partes.get(i)).getInsdBot()-10;
                            if (top[1] > ((Taza) partes.get(i)).getInsdBot() -10){
                                this.contenida = false;
                                partes.get(i).setTopped(this);
                            }
                            else{
                                this.contenida = true;
                            }
                            
                            for (int y = totalObjetos-contadorCambios; y < totalObjetos;y++){
                                if (!partes.get(y).isTopped() && this.topY <= partes.get(y).getTopY()){
                                    partes.get(y).setTopped(this);
                                }
                            }
                            estado = false;
                        }
                        
                    }
                    i ++;
                }
                
                if (estado){
                    this.ok = false;
                }
            }
        }
        else{
            this.ok = false;
        }
    }
    
    /**
     * Method that draw the lid
     */
    public void dibujar(){
        this.lid.makeVisible();
        
        if(this.differentiator1 != null){
            this.differentiator1.makeVisible();
            this.differentiator2.makeVisible();
        }
    }
    
    /**
     * Method that erase the lid
     */
    public void borrar(){
        if (this.ok){
            this.lid.makeInvisible();
            if (this.differentiator1 != null){
               this.differentiator1.makeInvisible();
               this.differentiator2.makeInvisible();
            }
        }
    }
    
    /**
     * Method that indicates that this is not a deep part
     */
    public boolean isDeep(){
        return false;
    }

    /**
     * Method that indicates if a lid is common (normal)
     * @return a boolean value that will be true just if the lid is normal
     */
    public boolean isCommon(){
        return false;
    }    
    
    /**
     * Method that indicates if a lid is afraid (fearful)
     * @return a boolean value that will be true just if the lid is fearful
     */
    public boolean isAfraid(){
        return false;
    }
    
    /**
     * Method that indicates if a lid is silly (crazy)
     * @return a boolean value that will be true just if the lid is crazy
     */
    public boolean isSilly(){
        return false;
    }
    
    /**
     * Method that draw 2 squiares to recognice when a cup i covered by its lid
     */
    public final void covered(){
        differentiator1 = new Rectangle(5, 5, this.medio-10, this.topY, "white", true);
        differentiator2 = new Rectangle(5, 5, this.medio+10, this.topY, "white", true);
    }
    
    public final void covered(boolean is){
        differentiator1 = new Rectangle(5, 5, this.medio-10, this.topY, "white", is);
        differentiator2 = new Rectangle(5, 5, this.medio+10, this.topY, "white", is);
    }
    

}