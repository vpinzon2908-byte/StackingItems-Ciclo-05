package tower;

import java.util.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * The test class TowerContestTest. 
 * This class contains the unit test cases from TowerContest class.
 

 * @author  Fierro-Pachón
 * @version 05
*/

public class TowerContestTest{
	
	/**
     * Default constructor for test class TowerTest
     */
    public TowerContestTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }
    
    @Test
    public void shouldSolve1(){
    	TowerContest prueba = new TowerContest();
    	String expected = "9 7 5 3 1";
    	assertEquals(prueba.solve(5, 9), expected);
    }
    
    @Test
    public void shouldSolve2(){
    	TowerContest prueba = new TowerContest();
    	String expected = "[3, 1, 7, 5, 9]";
    	assertEquals(prueba.solve(5, 15), expected);
    }
    
    @Test 
    public void shoulNotSolveSmaller(){
    	TowerContest prueba = new TowerContest();
    	String expected = "impossible";
    	assertEquals(prueba.solve(5, 2), expected);
    }
    
    @Test 
    public void shoulNotSolveEmpty(){
    	TowerContest prueba = new TowerContest();
    	String expected = "impossible";
    	assertEquals(prueba.solve(0, 2), expected);
    }
    
    @Test 
    public void shoulNotSolveBigest(){
    	TowerContest prueba = new TowerContest();
    	String expected = "impossible";
    	assertEquals(prueba.solve(4, 19), expected);
    }
    
    @Test public void shouldSimulate(){
    	TowerContest prueba = new TowerContest();
    	prueba.simulate(5, 9);
    	assertTrue(true);
    }
    
    @Test
    public void shouldNotSimulate(){
    	TowerContest prueba = new TowerContest();
    	prueba.simulate(5, 2);
    	assertTrue(true);
    }
    
    
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

}
