package tower;
import shapes.*;
import java.util.*;

/**
 * Class that describes a lid that will enter just if its related cup is in the tower
 * If it covers itd cup it will never get out.
 * 
 * @author Fierro-Pachón 
 * @version 05
 */
public class TapaFearful extends Tapa
{
    private Triangle triangle;
    /**
     * Constructor for objects of class Taza
     */
    public TapaFearful(int size, int[] top, int medio, ArrayList<Parte> partes, ArrayList<Integer> listaTipos,int contadorCambios,int totalObjetos,int tWidth,int topeTorre,boolean isVisible, String color)
    {
        super(size,top,medio,partes,listaTipos,contadorCambios,totalObjetos,tWidth,topeTorre,isVisible,color);
        this.triangle = new Triangle(8, 8, medio, this.topY, "white", true);
    }
    
    @Override
    /**
     * Method that indicates if a lid is afraid (fearful)
     * @return a boolean value that will be true just if the lid is fearful
     */
    public boolean isAfraid(){
        return true;
    }
    
    @Override
    public void dibujar(){
        super.dibujar();
        if (triangle != null){
            triangle.makeVisible();
        }
    }
    
    @Override
    public void borrar(){
        super.borrar();
        if (triangle != null){
            triangle.makeInvisible();
        }
    }
}