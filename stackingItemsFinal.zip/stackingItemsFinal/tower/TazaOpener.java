package tower;
import shapes.*;
import java.util.*;

/**
 * Class that describes a cup that will delete all the lids that avoids her entrance
 * 
 * @author Fierro-Pachón 
 * @version 05
 */
public class TazaOpener extends Taza
{
    private Circle circle;
    /**
     * Constructor for objects of class Taza
     */
    public TazaOpener(int size, int[] top, int medio, ArrayList<Parte> partes, ArrayList<Integer> listaTipos,int contadorCambios,int totalObjetos,int tWidth,int topeTorre, boolean isVisible, String color)
    {
        super(size,top,medio,partes,listaTipos,contadorCambios,totalObjetos,tWidth,topeTorre,isVisible,color);
        
        this.circle = new Circle(9, medio, this.lastY, "white", true);
    }
    
    @Override
    /**
     * Method that indicates if a Cup is starter (opener)
     * @return a boolean value that will be true just if the cup is opener
     */
        public boolean isStarter(){
        return true;
    }
    
    @Override
    public void dibujar(){
        super.dibujar();
        if (circle != null){
            circle.makeVisible();
        }
    }
    
    @Override
    public void borrar(){
        super.borrar();
        if (circle != null){
            circle.makeInvisible();
        }
    }
}