package tower;
import shapes.*;
import java.util.*;

/**
 * Class that describes a cup that will displace all the smaller items than it.
 * If it arrives to the bottom of the tower it will always stay there.
 * 
 * @author Fierro-Pachón 
 * @version 05
 */
public class TazaHierarchical extends Taza
{
    private Triangle triangle;
    /**
     * Constructor for objects of class Taza
     */
    public TazaHierarchical(int size, int[] top, int medio, ArrayList<Parte> partes, ArrayList<Integer> listaTipos,int contadorCambios,int totalObjetos,int tWidth,int topeTorre, boolean isVisible, String color){
        super(size,top,medio,partes,listaTipos,contadorCambios,totalObjetos,tWidth,topeTorre,isVisible,color);
        
        this.triangle = new Triangle(10, 10, medio, this.lastY, "white", true);
        

    }
    
    @Override
    /**
     * Method that indicates if a Cup is ranked (hierarchical)
     * @return a boolean value that will be true just if the cup is hierarchical
     */
    public boolean isRanked(){
        return true;
    }
    
    @Override
    public void dibujar(){
        super.dibujar();
        if (triangle != null){
            triangle.makeVisible();
        }
    }
    
    @Override
    public void borrar(){
        super.borrar();
        if (triangle != null){
            triangle.makeInvisible();
        }
    }
}