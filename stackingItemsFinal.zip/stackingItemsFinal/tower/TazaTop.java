package tower;
import shapes.*;
import java.util.*;

/**
 * Class that describes a cup that will be the last cup inserted in the tower.
 * 
 * @author Fierro-Pachón 
 * @version 05
 */
public class TazaTop extends Taza
{
    private Rectangle id;
    /**
     * Constructor for objects of class Taza
     */
    public TazaTop(int size, int[] top, int medio, ArrayList<Parte> partes, ArrayList<Integer> listaTipos,int contadorCambios,int totalObjetos,int tWidth,int topeTorre, boolean isVisible, String color){
        super(size,top,medio,partes,listaTipos,contadorCambios,totalObjetos,tWidth,topeTorre,isVisible,color);
        
        this.id = new Rectangle(5, 6, medio-1, this.lastY, "white", true);
    }
    
    @Override
    /**
     * Method that indicates if a Cup is ranked (hierarchical)
     * @return a boolean value that will be true just if the cup is hierarchical
     */
    public boolean isUpper(){
        return true;
    }
    
    @Override
    public void dibujar(){
        super.dibujar();
        if (id != null){
            id.makeVisible();
        }
    }
    
    @Override
    public void borrar(){
        super.borrar();
        if (id != null){
            id.makeInvisible();
        }
    }
}