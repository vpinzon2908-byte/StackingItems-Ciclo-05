package tower;
import shapes.*;
import java.util.*;
import javax.swing.JOptionPane;
/**
 * Clase que nos permite crear una tasa cuadrada con una base y dos paredes (todas de 1cm)
 * 
 * @author Fierro-Pachón 
 * @version 05
 */
public class TazaNormal extends Taza
{
    /**
     * Constructor of object of type cup
     */
    public TazaNormal(int size, int[] top, int medio, ArrayList<Parte> partes, ArrayList<Integer> listaTipos,int contadorCambios,int totalObjetos,int tWidth,int topeTorre, boolean isVisible, String color)
    {
        super(size,top,medio,partes,listaTipos,contadorCambios,totalObjetos,tWidth,topeTorre,isVisible,color);
    }
    
    @Override
    /**
     * Method that indicates if a Cup is common (normal)
     * @return a boolean value that will be true just if the cup is normal
     */
    public boolean isComon(){
        return true;
    }
    
}