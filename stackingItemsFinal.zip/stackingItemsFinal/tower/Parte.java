package tower;

import java.util.*;
/**
 * Abstract class that contains the common aspects of a Part of a Tower
 * 
 * @author Fierro-Pachon
 * @version 05
 */
public abstract class Parte
{
    protected int size;
    protected String myColor;
    protected boolean ok;
    protected boolean contenida;
    protected int topY;
    protected boolean isDeep; 
    protected int mid2;
    protected boolean isLided;
    protected Parte topped;
    protected int lastY;

    public Parte(int size, String color){
        this.size = size*10;
        
        mid2 = (int) (this.size/2);
        this.topped = null;
        this.myColor = color;
    }
    
    /**
     * Method that give us the color of the part
     * @return a String value that indicates the color of the part
     */
    public String getColor(){
        return this.myColor;
    }
    
    /**
     * Method that give us the size of the part
     * @return a int value that indicates the size of the part
     */
    public int getSize(){
        return this.size;
    }
    
    /**
     * Method to obtain the status of the last action
     * @return a boolean that indicates if the last action is done
     */    
    public boolean ok(){
        return this.ok;
    }
    
    /**
     * Methos that indicates if a part is contained in a part or not
     * @return true if it is contained or false otherwise
     */    
    public boolean getContenida(){
        return this.contenida;
    }
    
    /**
     * Method that gets the top of the tower
     * It means that gets the last position in the axis y
     * @return an int value that indicates the last position in y
     */    
    public int getTopY(){
        return this.topY;
    }
    
    /**
     * Method that return if the part is deep or not
     */
    public abstract boolean isDeep();
    
    /**
     * Abstract method that errase the part
     */
    public abstract void borrar();
    
    /**
     * Abstract method that draw the part
     */
    public abstract void dibujar();
    
    /**
     * Method to know if the part is lided or not
     */
    public boolean isLided(){
        return this.isLided;
    }
    
    public boolean isTopped(){
        if (this.topped != null){
            return true;
        }
        else{
            return false;
        }
    }
    
    public void setTopped(Parte s){
        this.topped = s;
    }
    
    public Parte getTopped(){
        return this.topped;
    }
    
}