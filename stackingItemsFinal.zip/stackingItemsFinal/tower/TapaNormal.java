package tower;
import shapes.*;
import java.util.*;
import javax.swing.JOptionPane;
/**
 * Class that creates cups
 * 
 * @author Fierro-Pachón 
 * @version 05
 */
public class TapaNormal extends Tapa
{
    
    /**
     * Constructor of objects type lid
     */
    public TapaNormal(int size, int[] top, int medio, ArrayList<Parte> partes, ArrayList<Integer> listaTipos,int contadorCambios,int totalObjetos,int tWidth,int topeTorre,boolean isVisible, String color)
    {
        super(size,top,medio,partes,listaTipos,contadorCambios,totalObjetos,tWidth,topeTorre,isVisible,color);
        
    }

    
    @Override
    /**
     * Method that indicates if a lid is common (normal)
     * @return a boolean value that will be true just if the lid is normal
     */
    public boolean isCommon(){
        return true; 
    }
    
}