package tower;

import java.util.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * The test class TowerTest. 
 * This class unifies all unit tests from all development cycles.
 

 * @author  Fierro-Pachón
 * @version 05
 */
public class TowerTest
{
    /**
     * Default constructor for test class TowerTest
     */
    public TowerTest() 
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }
    
    /**
     * Method that verifies the function of the constructor by number of cups
     */
    
    @Test
    public void shouldCreateTowerByCups(){
    	Tower prueba = new Tower(5, 250, 300, 34, 34);
    	String[][] contains = {{"cup", "1"}, {"cup", "3"}, {"cup", "5"}, {"cup", "7"}, {"cup", "9"}};
    	assertArrayEquals(prueba.stackingItems(), contains);
    }
    
    @Test
    public void shouldNotFailPop(){
        Tower prueba = new Tower(10,10,250,300);
        prueba.pushCup(3, "normal");
        prueba.pushLid(2, "normal");
        prueba.popLid();
        prueba.popCup();
        assertEquals(Tower.getTotalObjetos(),0);
        assertEquals(prueba.height(),0);
    }
    
    @Test
    public void shouldPushNormalCup(){
    	Tower prueba = new Tower(10,10,250,300);
        prueba.pushCup(10);
        assertEquals(prueba.height(),10);
    }
    
    @Test
    public void shouldPushNormalLid(){
    	Tower prueba = new Tower(10,10,250,300);
        prueba.pushLid(10);
        assertEquals(prueba.height(),1
        		);
    }
    
    @Test
    public void shouldNotPushNormalCup(){
    	Tower prueba = new Tower(10,10,250,300);
        prueba.pushCup(20);
        assertEquals(prueba.height(),0);
    }
    
    @Test
    public void shouldStackObjects(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(3, "normal");
    	prueba.pushLid(5, "normal");
    	prueba.pushLid(3, "normal");
    	prueba.pushCup(4, "normal");
    	prueba.pushCup(10, "normal");
    	prueba.pushCup(8, "normal");
    	prueba.pushCup(6, "normal");
    	prueba.pushCup(3, "normal");
    	prueba.pushLid(5, "normal");
    	prueba.pushLid(6, "normal");
    	prueba.pushLid(8, "normal");
    	prueba.pushLid(10, "normal");
    	assertEquals(prueba.height(),20);
    }
    
    @Test
    public void shouldOrderTower(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(3, "normal");
    	prueba.pushLid(5, "normal");
    	prueba.pushCup(4, "normal");
    	prueba.pushCup(10, "normal");
    	prueba.orderTower();
    	String[][] expectedOutput = new String[][] {{"cup", "10"}, {"lid", "5"}, {"cup", "4"}, {"cup", "3"}};
    	assertArrayEquals(prueba.stackingItems(), expectedOutput);
    }
    
    @Test
    public void shouldReverseTower(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(3, "normal");
    	prueba.pushLid(5, "normal");
    	prueba.pushCup(4, "normal");
    	prueba.pushCup(10, "normal");
    	prueba.pushCup(6, "normal");
    	prueba.reverseTower(); 
    	String[][] expectedOutput = new String[][] {{"cup", "3"}, {"cup", "4"}, {"lid", "5"}, {"cup", "6"}};
    	assertArrayEquals(prueba.stackingItems(), expectedOutput);
    }
    
    @Test
    public void shouldKeepInsideWhenReverseTower(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(3, "normal");
    	prueba.pushLid(5, "normal");
    	prueba.pushCup(4, "normal");
    	prueba.pushCup(10, "normal");
    	prueba.pushCup(6, "normal");
    	prueba.pushLid(10, "normal");
    	prueba.reverseTower(); 
    	String[][] expectedOutput = new String[][] {{"cup", "3"}, {"cup", "4"}, {"lid", "5"}, {"cup", "10"}, {"cup", "6"}, {"lid", "10"}};
    	assertArrayEquals(prueba.stackingItems(), expectedOutput);
    }
    
    @Test
    public void shouldKeepInsideWhenOrderTower(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(3, "normal");
    	prueba.pushLid(5, "normal");
    	prueba.pushCup(4, "normal");
    	prueba.pushCup(10, "normal");
    	prueba.pushCup(6, "normal");
    	prueba.pushLid(10, "normal");
    	prueba.orderTower();
    	String[][] expectedOutput = new String[][] {{"cup", "10"}, {"cup", "6"}, {"lid", "10"}, {"lid", "5"}, {"cup", "4"}, {"cup", "3"}};
    	assertArrayEquals(prueba.stackingItems(), expectedOutput);
    }
    
    @Test
    public void shouldSwapCupAndLid(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(3, "normal");
    	prueba.pushLid(5, "normal");
    	prueba.pushCup(4, "normal");
    	prueba.pushCup(10, "normal");
    	String[] first = new String[] {"cup", "3"};
    	String[] last = new String[] {"lid", "5"};
    	prueba.swap(first, last);
    	String[][] expectedOutput = new String[][] {{"lid", "5"}, {"cup", "3"},{"cup", "4"},{"cup", "10"}};
    	assertArrayEquals(prueba.stackingItems(), expectedOutput);
    }
    
    @Test
    public void shouldSwapLidAndCup(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(3, "normal");
    	prueba.pushLid(5, "normal");
    	prueba.pushCup(4, "normal");
    	prueba.pushCup(10, "normal");  
    	String[] first = new String[] {"lid", "5"};
    	String[] last = new String[] {"cup", "4"};
    	prueba.swap(first, last);
    	String[][] expectedOutput = new String[][] {{"cup", "3"}, {"cup", "4"}, {"lid", "5"}, {"cup", "10"}};
    	assertArrayEquals(prueba.stackingItems(), expectedOutput);
    }
    
    @Test
    public void shouldSwapCupAndCup(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(3, "normal");
    	prueba.pushLid(5, "normal");
    	prueba.pushCup(4, "normal");
    	prueba.pushCup(10, "normal");  
    	String[] first = new String[] {"cup", "4"};
    	String[] last = new String[] {"cup", "10"};
    	prueba.swap(first, last);
    	String[][] expectedOutput = new String[][] {{"cup", "3"}, {"lid", "5"}, {"cup", "10"}, {"cup", "4"}};
    	assertArrayEquals(prueba.stackingItems(), expectedOutput);
    }
    
    @Test
    public void shouldSwapLidAndLid(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(3, "normal");
    	prueba.pushLid(5, "normal");
    	prueba.pushCup(4, "normal");
    	prueba.pushCup(10, "normal");
    	prueba.pushLid(10, "normal");
    	String[] first = new String[] {"lid", "5"};
    	String[] last = new String[] {"lid", "10"};
    	prueba.swap(first, last);
    	String[][] expectedOutput = new String[][] {{"cup", "3"}, {"lid", "10"}, {"cup", "4"}, {"cup", "10"}, {"lid", "5"}};
    	assertArrayEquals(prueba.stackingItems(), expectedOutput);
    }
    
    @Test
    public void shouldNotSwapWithInexistent(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(3, "normal");
    	prueba.pushLid(5, "normal");
    	prueba.pushCup(4, "normal");
    	String[] first = new String[] {"lid", "5"};
    	String[] last = new String[] {"lid", "20"};
    	prueba.swap(first, last);
    	String[][] expectedOutput = new String[][] {{"cup", "3"}, {"lid", "5"}, {"cup", "4"}};
    	assertArrayEquals(prueba.stackingItems(), expectedOutput);
    }
    
    @Test
    public void shouldSwapToReduce(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(3, "normal");
    	prueba.pushCup(4, "normal");
    	prueba.pushCup(10, "normal");
    	int first = prueba.height();
    	String[][] changes = prueba.swapToReduce();
    	prueba.swap(changes[0], changes[1]);
    	int last = prueba.height();
    	assertTrue(first>last);
    }
    
    @Test
    public void shouldEraseAllFromCoveredCup(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(3, "normal");
    	prueba.pushLid(3, "normal");
    	prueba.removeCup(3);
    	assertEquals(prueba.height(),0);
    }
    
    @Test
    public void shouldEraseAllFromCoveredCupInTower(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(10, "normal");
    	prueba.pushCup(7, "normal");
    	prueba.pushLid(5, "normal");
    	prueba.pushCup(4, "normal");
    	prueba.pushLid(6, "normal");
    	prueba.pushLid(10, "normal");
    	prueba.removeCup(10);
    	assertEquals(prueba.height(),8);
    }
    
    @Test
    public void shouldShowStackingItems(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(10, "normal");
    	prueba.pushLid(5, "normal");
    	prueba.pushCup(7, "normal");
    	prueba.pushLid(6, "normal");
    	String[][] itemsInTower = {{"cup", "10"}, {"lid", "5"}, {"cup", "7"}, {"lid", "6"}};
    	assertArrayEquals(prueba.stackingItems(), itemsInTower);
    }
    
    @Test
    public void shouldShowStackingCups(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(10, "normal");
    	prueba.pushLid(5, "normal");
    	prueba.pushCup(7, "normal");
    	prueba.pushLid(6, "normal");
    	String[][] itemsInTower = {{"cup", "10"}, {"cup", "7"}};
    	assertArrayEquals(prueba.stackingCups(), itemsInTower);
    }
    
    @Test
    public void shouldShowStackingLids(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(10, "normal");
    	prueba.pushLid(5, "normal");
    	prueba.pushCup(7, "normal");
    	prueba.pushLid(6, "normal");
    	String[][] itemsInTower = {{"lid", "5"}, {"lid", "6"}};
    	assertArrayEquals(prueba.stackingLids(), itemsInTower);
    }
    
    @Test
    public void shouldNotSendMessageWhileInvisible(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.makeInvisible();
    	prueba.pushCup(10, "normal");
    	prueba.pushLid(5, "normal");
    	prueba.pushCup(7, "normal");
    	prueba.pushLid(6, "normal");
    	prueba.pushCup(15, "normal");
    	String[][] itemsInTower = {{"lid", "5"}, {"lid", "6"}};
    	assertArrayEquals(prueba.stackingLids(), itemsInTower);
    }
    
    @Test
    public void shouldPopCup(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(10, "normal");
    	prueba.popCup();
    	assertEquals(prueba.height(), 0);
    }
    
    @Test
    public void shouldPopLid(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushLid(10, "normal");
    	prueba.popLid();
    	assertEquals(prueba.height(), 0);
    }
    
    @Test
    public void shouldPushHierarchicalCup(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(10, "hierarchical");
    	TazaHierarchical actualCup = (TazaHierarchical)(Taza) Tower.getPartes().get(0) ;
    	assertTrue(actualCup.isRanked());
    }
    
    @Test
    public void shouldPushTopCup(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(10, "top");
    	TazaTop actualCup = (TazaTop)(Taza) Tower.getPartes().get(0) ;
    	assertTrue(actualCup.isUpper());
    }
    
    @Test
    public void shouldPushOpenerCup(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(10, "opener");
    	TazaOpener actualCup = (TazaOpener)(Taza) Tower.getPartes().get(0) ;
    	assertTrue(actualCup.isStarter());
    }
    
    @Test
    public void shouldPushANormalCup(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(10, "normal");
    	TazaNormal actualCup= (TazaNormal)(Taza) Tower.getPartes().get(0);
    	assertTrue(actualCup.isComon());
    }
    
    
    @Test
    public void shouldNotPushCupAfterTopCup(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.makeInvisible();
    	prueba.pushCup(10, "top");
    	prueba.pushCup(5, "top");
    	String[][] contains = {{"cup", "10"}};
    	assertArrayEquals(prueba.stackingItems(), contains);
    }
    
    @Test
    public void shouldNotPushTwiceAnExistentCup(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.makeInvisible();
    	prueba.pushCup(10, "normal");
    	prueba.pushCup(10, "normal");
    	String[][] contains = {{"cup", "10"}};
    	assertArrayEquals(prueba.stackingItems(), contains);
    }
    
    @Test
    public void shouldNotPushTwiceAnExistentLid(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.makeInvisible();
    	prueba.pushLid(10, "normal");
    	prueba.pushLid(10, "normal");
    	String[][] contains = {{"lid", "10"}};
    	assertArrayEquals(prueba.stackingItems(), contains);
    }
    
    
    @Test
    public void shouldPushFearfulLid(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(10, "normal");
    	prueba.pushLid(10, "fearful");
    	TapaFearful actualLid = (TapaFearful)(Tapa) Tower.getPartes().get(1);
    	assertTrue(actualLid.isAfraid());
    } 
    
    @Test
    public void shouldNotPushFearfulLid(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushLid(10, "fearful");
    	assertEquals(prueba.height(), 0);
    }
    
    @Test
    public void shouldPushSillyLid(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(10, "normal");
    	prueba.pushLid(10, "crazy");
    	TapaCrazy actualLid = (TapaCrazy)(Tapa) Tower.getPartes().get(1);
    	assertTrue(actualLid.isSilly());
    }
    
    @Test
    public void shouldPushANormalLid(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushLid(10, "normal");
    	TapaNormal actualLid = (TapaNormal)(Tapa) Tower.getPartes().get(0);
    	assertTrue(actualLid.isCommon());
    }
    
    
    
    @Test
    public void shouldRemoveCup(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.makeInvisible();
    	prueba.pushCup(10, "normal");
    	prueba.pushCup(5, "normal");
    	prueba.removeCup(10);
    	assertEquals(prueba.height(), 5);
    }
    
    @Test
    public void shouldRemoveLid(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.makeInvisible();
    	prueba.pushCup(5, "normal");
    	prueba.pushLid(5, "normal");
    	prueba.pushCup(10, "normal");
    	prueba.removeLid(5);
    	assertEquals(prueba.height(), 15);
    }
    
    @Test 
    public void shouldSayLidedCups(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.makeInvisible();
    	prueba.pushCup(5, "normal");
    	prueba.pushLid(5, "normal");
    	prueba.pushCup(10, "normal");
    	prueba.pushCup(7, "normal");
    	prueba.pushCup(2, "normal");
    	prueba.pushLid(7, "normal");
    	prueba.pushLid(10, "normal");
    	int[] lidedCups = new int[] {5,10,7};
    	assertArrayEquals(prueba.lidedCups(), lidedCups);
    }
    
    @Test 
    public void shouldRerun(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.makeInvisible();
    	prueba.pushCup(5, "normal");
    	prueba.pushLid(5, "normal");
    	prueba.pushCup(10, "normal");
    	prueba.pushCup(7, "normal");
    	prueba.pushCup(2, "normal");
    	prueba.pushLid(7, "normal");
    	prueba.pushLid(10, "normal");
    	prueba.rerun();
    	assertEquals(prueba.height(), 0);
    }
    
    @Test 
    public void shouldMakeVisibleAndInvisible(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.makeVisible();
    	assertTrue(prueba.isVisible());
    	prueba.makeInvisible();
    	assertTrue(!prueba.isVisible());
    }
    
    @Test 
    public void shouldGiveTopped(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.makeInvisible();
    	prueba.pushCup(10, "normal");
    	prueba.pushCup(7, "normal");
    	prueba.pushLid(7, "normal");
    	prueba.pushLid(10, "normal");
    	String[][] firstElements = new String[][] {{"cup", "10"}, {"cup", "7"}, {"lid", "7"}};
    	assertArrayEquals(prueba.getTopped(), firstElements);
    }
    
    @Test
    public void shouldHaveTheSameColorWhenCovered(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(10, "normal");
    	prueba.pushLid(10, "normal");
    	assertEquals(Tower.getPartes().get(0).getColor(), Tower.getPartes().get(1).getColor());
    }
    
    @Test
    public void shouldExit(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(10, "normal");
    	prueba.pushLid(10, "normal");
    	prueba.exit();
    	assertTrue(Tower.getPartes().isEmpty());
    }
    
    @Test
    public void shouldNotSwapToReduce(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(10, "normal");
    	String[][] expected = new String[][] {{"0", "0"}, {"0", "0"}};
    	assertArrayEquals(prueba.swapToReduce(), expected);
    }	
    	
    @Test
    public void shouldNotRemoveInExistentCup(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.removeCup(1);
    }
    
    @Test
    public void shouldNotRemoveInExistentLid(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.removeLid(1);
    }
    
    @Test
    public void shouldNotPopInExistentCup(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.popCup();
    }
    
    @Test
    public void shouldNotPopInExistentLid(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.popLid();
    }
    
    @Test
    public void shouldDrawAll(){
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.makeInvisible();
    	prueba.pushCup(10, "normal");
    	prueba.pushCup(7, "hierarchical");
    	prueba.pushCup(7, "opener");
    	prueba.pushLid(7, "normal");
    	prueba.pushLid(10, "fearful");
    	prueba.pushLid(10, "crazy");
    	prueba.pushCup(10, "top");
    	prueba.makeVisible();
    	prueba.makeInvisible();
    	assertTrue(true);
    }
    
    @Test
    public void shouldGetTopePixels() {
    	Tower prueba = new Tower(20,20,250,495);
    	prueba.pushCup(10, "normal");
    	prueba.pushCup(7, "hierarchical");
    	prueba.pushCup(7, "opener");
    	prueba.pushLid(7, "normal");
    	assertEquals(prueba.getTope(),295);
    }
    
    
    
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
}