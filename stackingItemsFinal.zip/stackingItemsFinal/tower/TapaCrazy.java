package tower;
import shapes.*;
import java.util.*;

/**
 * Class that describes a cup that, if it covers a cup, it will place in the bottom of that cup.
 * 
 * @author Fierro-Pachón 
 * @version 05
 */
public class TapaCrazy extends Tapa
{
    private Circle circle;
    
    /**
     * Constructor for objects of class Taza
     */
    public TapaCrazy(int size, int[] top, int medio, ArrayList<Parte> partes, ArrayList<Integer> listaTipos,int contadorCambios,int totalObjetos,int tWidth,int topeTorre,boolean isVisible, String color)
    {
        super(size,top,medio,partes,listaTipos,contadorCambios,totalObjetos,tWidth,topeTorre,isVisible,color);
        
        this.circle = new Circle(9, medio, this.topY, "white", true);
    }
    
    @Override
    /**
     * Method that indicates if a lid is silly (crazy)
     * @return a boolean value that will be true just if the lid is crazy
     */
    public boolean isSilly(){
        return true;
    }
    
    @Override
    public void dibujar(){
        super.dibujar();
        if (circle != null){
            circle.makeVisible();
        }
    }
    
    @Override
    public void borrar(){
        super.borrar();
        if (circle != null){
            circle.makeInvisible();
        }
    }
}