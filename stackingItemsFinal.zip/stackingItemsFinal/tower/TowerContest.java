package tower;
import shapes.*;
import java.util.*;
import javax.swing.JOptionPane;

/**
 * Class that solves and makes the graphic of the solution of the problem J
 * from the World Programming Competition - 2025
 * 
 * @author Fierro-Pachon
 * @version 05
 */
public class TowerContest
{
    private int n;
    private int h;
    private int[] cups;
    private int[] order;
    
    
    /**
     * Method that solves the problem
     * 
     * @param n is an integer of the number of cups
     * @param h is an integer of the wanted heigth
     */
    
    public TowerContest() {}
    
    public String solve(int n, int h){
        if(n == 0){
            return "impossible";
        }
        
        this.n = n;
        this.h = h;
        this.order = new int[n];

        
        StringBuilder answer = new StringBuilder();
        
        //creating the cups
        this.cups = new int[n];
        for(int i=0 ; i<n ; i++){
            this.cups[i] = 2*(i+1)-1;
        }
        // impossible case 
        // or exceedes max possible height created 
        // or is less than the min possible height created
        if( h>n*n  || h < 2*n-1){ 
            return "impossible";
        }
        //if the height is equal to the greatest cup
        else if (this.cups[n-1]==this.h){
            for(int i=n-1 ; i>=0 ; i--){
                answer.append(cups[i]).append(",");
            }
            if(answer.length()>0){
                answer.deleteCharAt(answer.length()-1); // borra la última coma
            }
            String finalAnswer = answer.toString();
            return finalAnswer.replace("[","").replace("]","").replace(","," ");
        }
        else { 
            return this.analice();
        }
    }
    
    /**
     * Method that draws the problem solution
     * 
     * @param n is an integer of the number of cups
     * @param h is an integer of the wanted heigth
     */
    public void simulate(int n, int h){
        String answer = this.solve(n, h);
        
        if (answer.equals("impossible")){
            JOptionPane.showMessageDialog(null, "This combination has no possible solution. Try again!");
        }
        else{
            ArrayList<Integer> solution = new ArrayList<>();

            answer = answer.replace(" ","");

            if(answer.isEmpty()){ 
                System.out.println("La respuesta es vacia");
            }

            for(String number : answer.split("")){
                if(!number.isEmpty() && number.matches("[0-9]")){
                    solution.add(Integer.parseInt(number));
                }
            }
            
            // Process to create board and define the basic measures to place the tower
            Canvas tablero = Canvas.getCanvas(h*20+100, h*20+100);
            Tower torre = new Tower(h, h, tablero.getMitad(), tablero.getHeight());
            
            for(int num:solution){
                torre.pushCup(num, "normal");
            }
            
            torre.makeVisible();
            try {
                Thread.sleep(5000); // waits 5 seconds
            } catch (InterruptedException e) {}
            
            tablero.erase();
            torre.makeInvisible();
            tablero.erase();
        }
    }
    
    /** 
     * Method that analices if a tower have the required height and if its cups are contained
     * @return "impossble" if there is no possibility to create the tower, therwise returns the tower order in a String
     */
    private String analice(){
        ArrayList<ArrayList<Integer>> matrix = this.options(this.cups);
        for(ArrayList<Integer> test : matrix){
            boolean ok = true;
            
            int towerHeight = this.calculateHeight(test);

            for(int i=0 ; i<test.size()-1 && ok ; i++){
                 if (test.get(i)< test.get(i+1)){
                    boolean found = false;
                    int posInCheck = i+1;
                    for(int j=i-1 ; j>=0 && !found ; j--){
                        if (test.get(j)> posInCheck){
                            found = true;
                            break;
                        }
                    }
                    
                    if (!found){
                        ok = false;
                    }
                }
            } 
            if(ok){
                return test.toString();
            } 
        }
        return "impossible";
    }
    
    /**
     * Method that calculates the height of a tower
     * 
     * @parm order an ArrayList with the tower in a detrmined order
     * @return a integer with the height of the tower with such order
     */
    private int calculateHeight(ArrayList<Integer> order){
        int n = order.size();
        
        int outside = 0;
        int inside = 1;
        int lastIn = order.get(0);
        
        for(int i = 0 ; i < n-1 ; i++){
            int down = order.get(i);
            int up = order.get(i+1);
            
            if (down > up){
                inside += 1;
                lastIn = up;
            }
            else{
                outside += (lastIn + 2*(inside-1));
                inside = 1;
                lastIn = up;
            }
        }
        
        outside += (lastIn + 2*(inside-1));
        
        return outside;
    }
    
    /**
     * Method that creates the possible options of order
     * 
     * @param cups an array that is a copy of the cups attribute
     * @return a 2D ArrayList with the possible optionss of orders
     */
    private ArrayList<ArrayList<Integer>> options(int[] cups){
        ArrayList<ArrayList<Integer>> answer = new ArrayList<>();
        permutar(cups,0,answer);
        return answer;
    }
    
    /**
     * Method that creates the possible permutations of the cups elemennts
     * 
     * @param keep is an auxiliary array that keeps the numbers being permuted 
     * @param idex is the index ihn wich we are located
     * @param answer is an ArrayList of ArrayLists of Integers with all the possible permutations
     */
    private void permutar(int[] keep,int index,ArrayList<ArrayList<Integer>> answer){
    
        if(index == keep.length){
            ArrayList<Integer> fila = new ArrayList<>();
            for(int n : keep){
                fila.add(n);
            }
            answer.add(fila);
            return;
        }
    
        for(int i=index;i<keep.length;i++){
            int temp = keep[index];
            keep[index] = keep[i];
            keep[i] = temp;
    
            permutar(keep,index+1,answer);
    
            temp = keep[index];
            keep[index] = keep[i];
            keep[i] = temp;
        }
    }
}