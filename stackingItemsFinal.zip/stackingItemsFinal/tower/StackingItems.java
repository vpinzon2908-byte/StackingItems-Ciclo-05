package tower;
import shapes.*;

import javax.swing.JOptionPane;
import java.util.*;

/**
 * class that simulates the construction of a tower with a specific hight and width, wich is made of cups and lids 
 * 
 * @author Fierro-Pachon 
 * @version 05
 */
public class StackingItems
{
    private Canvas tablero; //es el tablero del juego donde se ve todo
    private Tower torre; // es la torre del juego
    private List<String> possibleCups = Arrays.asList("normal", "opener", "hierarchical", "top"); //los tipos posibles de copas
    private List<String> possibleLids = Arrays.asList("normal", "fearful", "crazy"); //los tipos posibles de tazas

    /**
     * Constructor for objects of class StackingItems
     */
    public StackingItems(int wid, int maxHeig)
    {
        int width = wid;
        int maxHeight = maxHeig;
        // It must receive the dimensions of the centimeters required
        this.tablero = Canvas.getCanvas(width*20+100, maxHeight*20+100);
        
        String opcionConstructor = JOptionPane.showInputDialog("Escriba 'uno' para construir la torre dados el ancho y el alto o escriba 'dos' para constriurla según el número de tazas");
        
        if (opcionConstructor.equals("uno")) {
                torre = new Tower(width, maxHeight, this.tablero.getMitad(), this.tablero.getHeight());
        }
        else if(opcionConstructor.equals("dos")) {
                String cups = JOptionPane.showInputDialog("Escriba la cantidad de tasas");
                torre = new Tower(Integer.parseInt(cups), this.tablero.getMitad(), this.tablero.getHeight(),width, maxHeight);
        }
        
        if (torre == null){
            JOptionPane.showMessageDialog(null, "No se pudo crear la torre, vuelva a iniciar y escoja una opción válida",
                                                            "ERROR MESSAGE", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }
        cambioEntrada();
    }
    
    private void cambioEntrada(){
    	String entrada;
        while (true){
            
            entrada = JOptionPane.showInputDialog("Escriba el comando");
            boolean gotOk = false;
            if (entrada == null){ 
                continue;
            }
            else if (entrada.equals("pushCup")){
                boolean can = true;
                int size = 0;
                try{
                	size = Integer.parseInt(JOptionPane.showInputDialog("Escriba el tamaño de la taza"));
                }
                catch (Exception e){
                    can = false;
                    JOptionPane.showMessageDialog(null,"Size must be a number and must not be null");
                    torre.setOk(false);
                }
                
                if (can){
                    torre.pushCup(size);
                }
            }
            else if (entrada.equals("pushCupType")){
                boolean can = true;
                int size = 0;
                try{
                	size = Integer.parseInt(JOptionPane.showInputDialog("Escriba el tamaño de la taza"));
                }
                catch (Exception e){
                    can = false;
                    JOptionPane.showMessageDialog(null,"Size must be a number and must not be null");
                    torre.setOk(false);
                }
                
                String cupType = JOptionPane.showInputDialog("Escriba el tipo de taza");
                while (!this.possibleCups.contains(cupType)){
                    JOptionPane.showMessageDialog(null, "No ingresó un tipo de taza válido. Recuerde que las tazas pueden ser:  normal, opener, hierarchical o top");
                    cupType = JOptionPane.showInputDialog("Escriba el tipo de taza");
                }
                
                if (can){
                    torre.pushCup(size, cupType);
                }
            }
            else if (entrada.equals("pushLid")){
                boolean can = true;
                int size = 0;
                try{
                	size = Integer.parseInt(JOptionPane.showInputDialog("Escriba el tamaño de la tapa"));
                }
                catch(Exception e){
                    can = false;
                    JOptionPane.showMessageDialog(null,"Size must be a number and must not be null");
                    torre.setOk(false);
                }
                
                if (can){
                    torre.pushLid(size);
                }
            }
            else if (entrada.equals("pushLidType")){
                boolean can = true;
                int size = 0;
                try{
                	size = Integer.parseInt(JOptionPane.showInputDialog("Escriba el tamaño de la tapa"));
                }
                catch(Exception e){
                    can = false;
                    JOptionPane.showMessageDialog(null,"Size must be a number and must not be null");
                    torre.setOk(false);
                }
                
                String lidType = JOptionPane.showInputDialog("Escriba el tipo de tapa");
                while (!this.possibleLids.contains(lidType)){
                    JOptionPane.showMessageDialog(null, "No ingresó un tipo de tapa válido. Recuerde que las tazas pueden ser:  normal, fearful o crazy");
                    lidType = JOptionPane.showInputDialog("Escriba el tipo de tapa");
                }
                
                if (can){
                    torre.pushLid(size, lidType);
                }
            }
                
            else if (entrada.equals("ok")){
                boolean estado = torre.ok();
                gotOk = true;
                if (estado) {
                    JOptionPane.showMessageDialog(null, "Sí se pudo realizar la anterior acción",
                                                            "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
                }
                else {
                    JOptionPane.showMessageDialog(null, "No se pudo realizar la anterior acción",
                                                            "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            else if (entrada.equals("height")){
                JOptionPane.showMessageDialog(null, torre.height(),
                                                            "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
            }
            
            else if (entrada.equals("popCup")){
                torre.popCup();
            }
            else if (entrada.equals("popLid")){
                torre.popLid();
            }
            else if (entrada.equals("stackingItems")){
                JOptionPane.showMessageDialog(null, torre.stackingItems(),
                                                            "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
            }
            else if (entrada.equals("stackingCups")){
                JOptionPane.showMessageDialog(null, torre.stackingCups(),
                                                            "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
            }
            else if (entrada.equals("stackingLids")){
                JOptionPane.showMessageDialog(null, torre.stackingLids(),
                                                            "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
            }
            
            else if (entrada.equals("visible")){
                torre.makeVisible();
            }
            else if (entrada.equals("inVisible")){
                torre.makeInvisible();
            }
            
            else if (entrada.equals("swap")){
                String[] first = new String[2];
                String[] last = new String[2];
                String m = "a";
                String n = "a";
                boolean can1 = true;
                boolean can2 = true;
                try{
                    m = JOptionPane.showInputDialog("Escriba el tipo del primer objeto");
                    n = JOptionPane.showInputDialog("Escriba el tamaño del primer objeto");
                    int x = Integer.parseInt(n);
                }
                catch(Exception e ){
                	JOptionPane.showMessageDialog(null,"Invalid data to continue the swap");
                    can1 = false;
                    torre.setOk(false);
                }
                if (can1){
                    first[0] = m;
                    first[1] = n;
                    try{
                        m = JOptionPane.showInputDialog("Escriba el tipo del segundo objeto");
                        n = JOptionPane.showInputDialog("Escriba el tamaño del segundo objeto");
                        int x = Integer.parseInt(n);
                    }
                    catch (Exception e){
                        can2 = false;
                        JOptionPane.showMessageDialog(null,"Invalid data to continue the swap.");
                        torre.setOk(false);
                    }
                }
                if (can1 && can2){
                    last[0] = m;
                    last[1] = n;
                    torre.swap(first, last);
                }
            }
            
            else if (entrada.equals("orderTower")){
                torre.orderTower();
            }
            
            else if (entrada.equals("reverseTower")){
                torre.reverseTower();
            }
            else if (entrada.equals("lidedCups")){
                JOptionPane.showMessageDialog(null, Arrays.toString(torre.lidedCups()),
                                                            "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
            }
            else if(entrada.equals("removeCup")){
                int size = 0;
                boolean can = true;
                try{
                	size = Integer.parseInt(JOptionPane.showInputDialog("Escriba el tamaño de la taza"));
                }
                catch(Exception e){
                    can = false;
                    JOptionPane.showMessageDialog(null,"Size must be a number and must not be null");
                    torre.setOk(false);
                }
                
                if (can){
                    torre.removeCup(size);
                }
            }
            else if(entrada.equals("removeLid")){
                int size = 0;
                boolean can = true;
                try{
                	size = Integer.parseInt(JOptionPane.showInputDialog("Escriba el tamaño de la tapa"));
                }
                catch(Exception e){
                    can = false;
                    JOptionPane.showMessageDialog(null,"Size must be a number and must not be null");
                    torre.setOk(false);
                }
                
                if (can){
                    torre.removeLid(size);
                }
            }
            else if(entrada.equals("swapToReduce")){
                String[][] aux = torre.swapToReduce();
                String show = "Part 1: "+Arrays.toString(aux[0])+ "\nPart 2: "+Arrays.toString(aux[1]);
                JOptionPane.showMessageDialog(null, show,
                                                            "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
            }
            else if (entrada.equals("exit")){
                System.exit(0);
                torre.exit();
                break;
            }
            
            //testing methods
            else if (entrada.equals("top")){
                JOptionPane.showMessageDialog(null, torre.getTop()[0],
                                                            "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
                JOptionPane.showMessageDialog(null, torre.getTop()[1],
                                                            "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
            }
            else if (entrada.equals("tope")){
                JOptionPane.showMessageDialog(null, torre.getTope(),
                                                            "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
            }
            else if (entrada.equals("objetos")){
                JOptionPane.showMessageDialog(null, torre.getTotalObjetos(),
                                                            "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
            }
            else if (entrada.equals("mitad")){
                JOptionPane.showMessageDialog(null, this.tablero.getMitad(),
                                                            "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
            }
            else if (entrada.equals("Partes")){
                JOptionPane.showMessageDialog(null, Tower.getPartes(),
                                                            "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
            }
            else if (entrada.equals("contadorCambios")){
                JOptionPane.showMessageDialog(null, Tower.getContadorCambios(),
                                                            "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
            }
            else if (entrada.equals("listatipos")){
                JOptionPane.showMessageDialog(null, Tower.getListaTipos(),
                                                            "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
            }
            else if (entrada.equals("getTopped")){
                JOptionPane.showMessageDialog(null, torre.getTopped(),
                                                            "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
            }
            else if (entrada.equals("topY")){
                JOptionPane.showMessageDialog(null, torre.getTopY(),
                                                            "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
            }
            else if (entrada.equals("rerun")){
                torre.rerun();
            }
            else if (entrada.equals("TowerContest")){
                TowerContest contest = new TowerContest();
                
                int cant = 0;
                int height = 0;
                
                try{
                    cant = Integer.parseInt(JOptionPane.showInputDialog("Escriba la cantidad de tazas"));
                }
                catch (Exception e){
                    JOptionPane.showMessageDialog(null,"cant must be a number and must not be null");
                    torre.setOk(false);
                }  
                try{
                    height = Integer.parseInt(JOptionPane.showInputDialog("Escriba la altura deseada"));
                }
                catch (Exception e){
                    JOptionPane.showMessageDialog(null,"height must be a number and must not be null");
                    torre.setOk(false);
                }     
                
                String action = JOptionPane.showInputDialog("¿Desea simular (simulate) o resolver (solve)?");
                if (action.equals("simulate")){
                    try{
                        contest.simulate(cant, height);
                    }
                    catch(Exception e){
                        JOptionPane.showMessageDialog(null, "Sorry, something went wrong");
                    }
                }
                else if (action.equals("solve")){
                    try{
                        contest.solve(cant, height);
                    }
                    catch(Exception e){
                        JOptionPane.showMessageDialog(null, "Sorry, something went wrong");
                    }
                }
                else{
                    JOptionPane.showMessageDialog(null, "No ingresó una entrada válida");
                }
            }
            if (torre.isVisible() && !torre.ok() && !gotOk){
                JOptionPane.showMessageDialog(null, "No se pudo realizar la anterior acción",
                                                            "INFORMATION_MESSAGE", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }
    public Tower getTower(){
        return this.torre;
    }
}